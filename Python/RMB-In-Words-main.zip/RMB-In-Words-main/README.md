# 数字金额转换成人民币大写 Convert Numerical Amount  Into RMB In Words  

介于WPS新增加了JS宏功能，故用js写了一个将数字金额转换为人民币大写的功能，可用于js宏的自定义函数在WPS文件中使用（与excel表格类似）。后续将陆续添加其他语言的实现。

Since the JS macro function is newly added to WPS, a function is written in JS to convert digital amount into RMB in words, which can be used for the user-defined function of JS macro to be used in WPS files (similar to excel). Other languages will be added in the future.

目前已实现的语言如下 At present, the languages are as follows:

* JavaScript
* Python
